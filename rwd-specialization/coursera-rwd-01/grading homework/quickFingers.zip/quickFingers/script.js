function getRandomColor() {
  var letters = '0123456789ABCDEF'.split('');
  var color = '#';
  for (var i = 0; i < 6; i++ ) {
      color += letters[Math.floor(Math.random() * 16)];
  }
  return color;
  }

var createTime;
var clickTime;
var reactTime;

function makebox(){

  var time=Math.random();
  time =time*5000;

  setTimeout(function(){

    if(Math.random()>0.5){
    document.getElementById("box").style.borderRadius="3em";
    }else{
    document.getElementById("box").style.borderRadius="0";
    }

    var top=Math.random();
    top=top*200;

    var left=Math.random();
    left=left*300;

    document.getElementById("box").style.top=top+"px";
    document.getElementById("box").style.left=left+"px";
    document.getElementById("box").style.backgroundColor=getRandomColor();
    document.getElementById("box").style.display="block";
    createTime=Date.now();
  }, time);
  }

document.getElementById("box").onclick=function(){

    clickTime=Date.now();
    reactTime=(createTime-clickTime)/1000;

    document.getElementById("time").innerHTML=reactTime;
    makebox();
};

makebox();
