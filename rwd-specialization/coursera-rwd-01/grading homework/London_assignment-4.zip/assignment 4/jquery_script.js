$(document).ready(function() { 
    $('#two').fadeIn(1500).delay(3500).fadeOut(1500);
    $('#one').delay(5000).fadeIn(1500);
});

$(document).ready(function() { 
    $(".extra").hover(function(){
    	$("#clock").hide(1000);
}, 
    function(){
    	$("#clock").show(1000);

    });


    $("#fname,#lname,#age,#country,#email,#comments").each(function(){
    	$(this).focus(function(){

    		$(this).css("background-color","lightgrey");
});
    });

      $("#fname,#lname,#age,#country,#email,#comments").each(function(){
    	$(this).blur(function(){

    		$(this).css("background-color","white");
});
    });
 });   