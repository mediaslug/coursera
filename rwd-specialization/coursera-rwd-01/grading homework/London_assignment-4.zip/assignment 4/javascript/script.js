
window.onload=startOnload;




function startOnload(){


	DisplayClock();
	displayText();
}

function DisplayClock(){


	time=new Date();
	hours=time.getHours();
	minutes=time.getMinutes();
	seconds=time.getSeconds();
	meridiem="AM";
	if(hours==0){
		hours=12;
	}

	if(hours>12){
		hours=hours-12;
		meridiem="PM";
	}

	if(hours<10){

		hours="0"+hours;
	}

	if(minutes<10){

		minutes="0"+minutes;
	}

	if(seconds<10){

		seconds="0"+seconds;
	}

	var showTime=hours+":"+minutes+":"+seconds+" "+meridiem;

	var getId=document.getElementById("clock");
	getId.innerHTML=showTime;
	setTimeout("DisplayClock()",1000);




}


function displayForm(){

	var goToForm=document.getElementById("contactForm");

	var user_input=confirm("Would you like to see my form?");
	if(user_input==true){

		window.location.href="myForm.html";
	}
	else{



		goToForm.innerHTML="<b>You missed your opportunity to see a nice form</b><br />";
		createButton();
	}

	function createButton(){

		var goBack=document.getElementById("contactForm");


		var buttonCreated = document.createElement("input");
    	buttonCreated.setAttribute("type", "button");
    	buttonCreated.setAttribute("value", "Co Back!");
    	buttonCreated.setAttribute("id", "bClick!");
    	goBack.appendChild(buttonCreated);
    	buttonCreated.style.height="30px";
    	buttonCreated.style.width="90px";
    	buttonCreated.style.backgroundColor="gray";
    	buttonCreated.style.color="white";
    	buttonCreated.style.borderRadius="5px";
    	buttonCreated.style.textAlign="center";
    	buttonCreated.onclick=returnFunc;

	}

	function returnFunc(){

		window.location.href="Contact.html";
	}


}


function displayText(){

	var text=document.getElementById("comments");
var cnt="Please type in your comments below";

text.innerHTML=cnt;
text.style.color="#a09778";

text.onclick=function(){
text.innerHTML=" ";

}

}

