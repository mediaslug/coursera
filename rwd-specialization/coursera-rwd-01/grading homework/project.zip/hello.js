$( document ).ready(function() {
    $("button").click(function() {
    	var name = prompt("Hi! What is your name?");
    	$("#msg").html("Hi! " + name + ". Red panda says Hi!");
    });
});