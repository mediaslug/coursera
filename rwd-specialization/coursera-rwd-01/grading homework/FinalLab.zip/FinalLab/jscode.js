// JavaScript file for final Lab

// syllabus starting week
var week = 1;
// show contents of the first week
showWeek(week);

// Event handlers for buttons
$('#nextButton').click(function () {
    // hide current week
    hideWeek(week);
	if ( week == 4 )
	   week = 1;
	else week += 1;
	// show new week
	showWeek(week);
});
$('#prevButton').click(function () {
    // hide current week
    hideWeek(week); 
	if ( week == 1 )
	   week = 4;
	else week -= 1;
	// show previous week
	showWeek(week);
});

function hideWeek(num) {
    $('#week' + num).css({display: "none"});        	
}

function showWeek(num) {
    $("#week" + num).css({display: "block"});        	
}

function toggleInstructions() {
    var instructions = document.getElementById("instructions");
    var text = document.getElementById("showhidelink");
    if( instructions.style.display == "block" ) {
        instructions.style.display = "none";
        text.innerHTML = "Click me to show instructions";
    }
    else {
        instructions.style.display = "block";
        text.innerHTML = "Click me to hide instructions";
    }
}